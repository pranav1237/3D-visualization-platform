// Global state
let currentUser = null;
let authToken = null;
let currentScene = null;
let currentCamera = null;
let currentRenderer = null;
let currentControls = null;

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initDemo3DViewer();
});

// Check authentication status
function checkAuth() {
    authToken = localStorage.getItem('authToken');
    if (authToken) {
        // Verify token with backend
        axios.get('/api/subscription/status', {
            headers: { 'Authorization': `Bearer ${authToken}` }
        })
        .then(response => {
            currentUser = response.data;
            updateUIForLoggedInUser();
        })
        .catch(() => {
            // Token invalid, clear it
            localStorage.removeItem('authToken');
            authToken = null;
        });
    }
}

// Update UI for logged-in user
function updateUIForLoggedInUser() {
    document.getElementById('nav-buttons').classList.add('hidden');
    document.getElementById('user-menu').classList.remove('hidden');
}

// Show/Hide sections
function showLogin() {
    document.getElementById('login-modal').classList.add('active');
}

function showSignup() {
    document.getElementById('signup-modal').classList.add('active');
}

function showDashboard() {
    document.getElementById('hero-section').classList.add('hidden');
    document.getElementById('features-section').classList.add('hidden');
    document.getElementById('pricing-section').classList.add('hidden');
    document.getElementById('dashboard-section').classList.remove('hidden');
    loadDashboard();
}

function closeModals() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('active');
    });
}

// Authentication handlers
async function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const response = await axios.post('/api/auth/login', { email, password });
        authToken = response.data.token;
        currentUser = response.data.user;
        localStorage.setItem('authToken', authToken);
        
        closeModals();
        updateUIForLoggedInUser();
        showDashboard();
        
        showNotification('Login successful!', 'success');
    } catch (error) {
        showNotification(error.response?.data?.error || 'Login failed', 'error');
    }
}

async function handleSignup(event) {
    event.preventDefault();
    const full_name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    try {
        const response = await axios.post('/api/auth/signup', { email, password, full_name });
        authToken = response.data.token;
        currentUser = response.data.user;
        localStorage.setItem('authToken', authToken);
        
        closeModals();
        updateUIForLoggedInUser();
        showDashboard();
        
        showNotification('Account created successfully!', 'success');
    } catch (error) {
        showNotification(error.response?.data?.error || 'Signup failed', 'error');
    }
}

function logout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    
    document.getElementById('nav-buttons').classList.remove('hidden');
    document.getElementById('user-menu').classList.add('hidden');
    document.getElementById('dashboard-section').classList.add('hidden');
    document.getElementById('hero-section').classList.remove('hidden');
    document.getElementById('features-section').classList.remove('hidden');
    document.getElementById('pricing-section').classList.remove('hidden');
    
    showNotification('Logged out successfully', 'success');
}

// Dashboard functions
async function loadDashboard() {
    try {
        // Load subscription status
        const subResponse = await axios.get('/api/subscription/status', {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        const subData = subResponse.data;
        document.getElementById('subscription-details').innerHTML = `
            <div class="grid md:grid-cols-3 gap-6">
                <div>
                    <p class="text-gray-600">Current Plan</p>
                    <p class="text-2xl font-bold ${subData.subscription.tier === 'premium' ? 'text-purple-600' : 'text-gray-800'}">${subData.subscription.tier.toUpperCase()}</p>
                </div>
                <div>
                    <p class="text-gray-600">Projects Used</p>
                    <p class="text-2xl font-bold">${subData.usage.projects} / ${subData.limits.projects}</p>
                </div>
                <div>
                    <p class="text-gray-600">AI Visualizations</p>
                    <p class="text-2xl font-bold">${subData.usage.ai_visualizations} / ${subData.limits.ai_visualizations}</p>
                </div>
            </div>
            ${subData.subscription.tier === 'free' ? `
                <div class="mt-6">
                    <button onclick="upgradeToPremium()" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                        <i class="fas fa-crown mr-2"></i> Upgrade to Premium
                    </button>
                </div>
            ` : ''}
        `;

        // Load projects
        const projectsResponse = await axios.get('/api/projects', {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        const projects = projectsResponse.data.projects;
        const projectsGrid = document.getElementById('projects-grid');
        
        if (projects.length === 0) {
            projectsGrid.innerHTML = `
                <div class="col-span-3 text-center py-12">
                    <i class="fas fa-folder-open text-6xl text-gray-300 mb-4"></i>
                    <p class="text-xl text-gray-600">No projects yet. Create your first project!</p>
                </div>
            `;
        } else {
            projectsGrid.innerHTML = projects.map(project => `
                <div class="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
                    <div class="flex justify-between items-start mb-4">
                        <h3 class="text-xl font-bold">${project.title}</h3>
                        <span class="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">${project.project_type}</span>
                    </div>
                    <p class="text-gray-600 mb-4">${project.description || 'No description'}</p>
                    <div class="flex gap-2">
                        <button onclick="openProject(${project.id})" class="flex-1 px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 transition">
                            <i class="fas fa-edit mr-2"></i> Open
                        </button>
                        <button onclick="deleteProject(${project.id})" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `).join('');
        }
    } catch (error) {
        showNotification('Failed to load dashboard', 'error');
    }
}

function createNewProject() {
    document.getElementById('project-modal').classList.add('active');
    // Initialize 3D viewer in modal
    setTimeout(() => {
        init3DViewer('project-viewer');
    }, 100);
}

async function handleCreateProject(event) {
    event.preventDefault();
    
    const title = document.getElementById('project-title').value;
    const description = document.getElementById('project-description').value;
    const project_type = document.getElementById('project-type').value;
    
    try {
        const response = await axios.post('/api/projects', {
            title,
            description,
            project_type,
            model_data: JSON.stringify({ version: '1.0', objects: [] })
        }, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        closeModals();
        showNotification('Project created successfully!', 'success');
        loadDashboard();
    } catch (error) {
        showNotification(error.response?.data?.error || 'Failed to create project', 'error');
    }
}

async function openProject(projectId) {
    showNotification('Opening project editor...', 'info');
    // In a real app, this would open a full 3D editor
}

async function deleteProject(projectId) {
    if (!confirm('Are you sure you want to delete this project?')) return;
    
    try {
        await axios.delete(`/api/projects/${projectId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        showNotification('Project deleted successfully', 'success');
        loadDashboard();
    } catch (error) {
        showNotification('Failed to delete project', 'error');
    }
}

async function upgradeToPremium() {
    try {
        const response = await axios.post('/api/subscription/create-checkout', {
            plan: 'monthly'
        }, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        // Simulate payment
        showNotification('Redirecting to payment...', 'info');
        
        // In production, redirect to Stripe checkout
        setTimeout(async () => {
            // Simulate successful payment
            await axios.post('/api/subscription/webhook', {
                session_id: response.data.session_id,
                status: 'completed'
            }, {
                headers: { 'Authorization': `Bearer ${authToken}` }
            });
            
            showNotification('Payment successful! You are now a Premium member!', 'success');
            loadDashboard();
        }, 2000);
    } catch (error) {
        showNotification('Failed to process payment', 'error');
    }
}

// 3D Viewer functions
function initDemo3DViewer() {
    init3DViewer('viewer-container');
}

function init3DViewer(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x1a1a2e);
    
    // Camera setup
    const camera = new THREE.PerspectiveCamera(75, container.offsetWidth / container.offsetHeight, 0.1, 1000);
    camera.position.set(5, 5, 5);
    
    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.offsetWidth, container.offsetHeight);
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    
    // Controls
    const controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 10, 5);
    scene.add(directionalLight);
    
    // Grid
    const gridHelper = new THREE.GridHelper(20, 20, 0x444444, 0x222222);
    scene.add(gridHelper);
    
    // Create a simple bridge structure
    createBridgeStructure(scene);
    
    // Animation loop
    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }
    animate();
    
    // Handle window resize
    window.addEventListener('resize', () => {
        if (container.offsetWidth > 0) {
            camera.aspect = container.offsetWidth / container.offsetHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(container.offsetWidth, container.offsetHeight);
        }
    });
    
    // Store references
    currentScene = scene;
    currentCamera = camera;
    currentRenderer = renderer;
    currentControls = controls;
}

function createBridgeStructure(scene) {
    // Bridge deck
    const deckGeometry = new THREE.BoxGeometry(10, 0.3, 2);
    const deckMaterial = new THREE.MeshPhongMaterial({ color: 0x808080 });
    const deck = new THREE.Mesh(deckGeometry, deckMaterial);
    deck.position.y = 1;
    scene.add(deck);
    
    // Support pillars
    const pillarGeometry = new THREE.CylinderGeometry(0.3, 0.3, 2, 16);
    const pillarMaterial = new THREE.MeshPhongMaterial({ color: 0x606060 });
    
    for (let i = -3; i <= 3; i += 3) {
        const pillar = new THREE.Mesh(pillarGeometry, pillarMaterial);
        pillar.position.set(i, 0, 0);
        scene.add(pillar);
    }
    
    // Cables
    const cableMaterial = new THREE.LineBasicMaterial({ color: 0xffff00 });
    
    for (let i = -4; i <= 4; i += 0.5) {
        const points = [];
        points.push(new THREE.Vector3(i, 1.15, 0.8));
        points.push(new THREE.Vector3(i, 3, 0));
        points.push(new THREE.Vector3(i, 1.15, -0.8));
        
        const geometry = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(geometry, cableMaterial);
        scene.add(line);
    }
    
    // Main tower
    const towerGeometry = new THREE.BoxGeometry(0.5, 4, 0.5);
    const towerMaterial = new THREE.MeshPhongMaterial({ color: 0x404040 });
    const tower = new THREE.Mesh(towerGeometry, towerMaterial);
    tower.position.y = 2;
    scene.add(tower);
}

// Notification system
function showNotification(message, type = 'info') {
    const colors = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        info: 'bg-blue-500'
    };
    
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-4 rounded-lg shadow-lg z-50`;
    notification.innerHTML = `
        <div class="flex items-center gap-3">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}
