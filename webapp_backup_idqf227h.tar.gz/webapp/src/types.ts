export type Bindings = {
  DB: D1Database;
}

export type Variables = {
  user?: {
    id: number;
    email: string;
    subscription_tier: string;
  }
}

export interface User {
  id: number;
  email: string;
  full_name: string;
  subscription_tier: 'free' | 'premium';
  created_at: string;
}

export interface Project {
  id: number;
  user_id: number;
  title: string;
  description?: string;
  project_type: 'bridge' | 'road' | 'building' | 'infrastructure' | 'other';
  model_data?: string;
  thumbnail_url?: string;
  is_public: number;
  created_at: string;
  updated_at: string;
}

export interface AIVisualization {
  id: number;
  project_id: number;
  user_id: number;
  visualization_type: string;
  ai_model: string;
  input_prompt?: string;
  result_data?: string;
  created_at: string;
}
