import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { serveStatic } from 'hono/cloudflare-workers';
import type { Bindings, Variables } from './types';

// Import routes
import auth from './routes/auth';
import projects from './routes/projects';
import ai from './routes/ai';
import subscription from './routes/subscription';

const app = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// Enable CORS for API routes
app.use('/api/*', cors());

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }));

// API Routes
app.route('/api/auth', auth);
app.route('/api/projects', projects);
app.route('/api/ai', ai);
app.route('/api/subscription', subscription);

// Health check
app.get('/api/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Main app route
app.get('/', (c) => {
  return c.html(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D Model Builder Pro - Professional Infrastructure Visualization</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.160.0/examples/js/controls/OrbitControls.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2563eb',
                        secondary: '#7c3aed'
                    }
                }
            }
        }
    </script>
    <style>
        body { margin: 0; overflow-x: hidden; }
        .gradient-bg { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .glass { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); }
        #viewer-container { width: 100%; height: 500px; background: #1a1a2e; border-radius: 8px; }
        .feature-card { transition: transform 0.3s; }
        .feature-card:hover { transform: translateY(-5px); }
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); }
        .modal.active { display: flex; align-items: center; justify-content: center; }
        .modal-content { background: white; padding: 2rem; border-radius: 8px; max-width: 500px; width: 90%; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="gradient-bg text-white shadow-lg">
        <div class="container mx-auto px-6 py-4">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-cube text-3xl"></i>
                    <span class="text-2xl font-bold">3D Model Builder Pro</span>
                </div>
                <div id="nav-buttons" class="space-x-4">
                    <button onclick="showLogin()" class="px-6 py-2 bg-white text-purple-700 rounded-lg font-semibold hover:bg-gray-100 transition">
                        Login
                    </button>
                    <button onclick="showSignup()" class="px-6 py-2 bg-purple-900 text-white rounded-lg font-semibold hover:bg-purple-800 transition">
                        Sign Up
                    </button>
                </div>
                <div id="user-menu" class="hidden space-x-4">
                    <button onclick="showDashboard()" class="px-6 py-2 bg-white text-purple-700 rounded-lg font-semibold hover:bg-gray-100 transition">
                        Dashboard
                    </button>
                    <button onclick="logout()" class="px-6 py-2 bg-purple-900 text-white rounded-lg font-semibold hover:bg-purple-800 transition">
                        Logout
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="hero-section" class="gradient-bg text-white py-20">
        <div class="container mx-auto px-6 text-center">
            <h1 class="text-5xl font-bold mb-6">Build Professional 3D Infrastructure Models</h1>
            <p class="text-xl mb-8">Design bridges, roads, buildings with AI-powered visualization and structural analysis</p>
            <button onclick="showSignup()" class="px-8 py-4 bg-white text-purple-700 rounded-lg font-bold text-lg hover:bg-gray-100 transition">
                Get Started Free <i class="fas fa-arrow-right ml-2"></i>
            </button>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features-section" class="py-20">
        <div class="container mx-auto px-6">
            <h2 class="text-4xl font-bold text-center mb-12 text-gray-800">Powerful Features</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="feature-card bg-white p-8 rounded-lg shadow-lg">
                    <i class="fas fa-cube text-5xl text-blue-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-3">3D Modeling</h3>
                    <p class="text-gray-600">Create detailed 3D models for bridges, roads, buildings, and more with intuitive tools</p>
                </div>
                <div class="feature-card bg-white p-8 rounded-lg shadow-lg">
                    <i class="fas fa-brain text-5xl text-purple-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-3">AI Analysis</h3>
                    <p class="text-gray-600">Get AI-powered structural analysis, load calculations, and design recommendations</p>
                    <span class="inline-block mt-2 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold">Premium</span>
                </div>
                <div class="feature-card bg-white p-8 rounded-lg shadow-lg">
                    <i class="fas fa-paint-brush text-5xl text-green-600 mb-4"></i>
                    <h3 class="text-2xl font-bold mb-3">Visualization</h3>
                    <p class="text-gray-600">Enhanced rendering with realistic materials, lighting, and environmental effects</p>
                    <span class="inline-block mt-2 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold">Premium</span>
                </div>
            </div>
        </div>
    </section>

    <!-- 3D Viewer Demo -->
    <section class="py-20 bg-gray-100">
        <div class="container mx-auto px-6">
            <h2 class="text-4xl font-bold text-center mb-12 text-gray-800">Interactive 3D Viewer</h2>
            <div id="viewer-container"></div>
            <div class="text-center mt-6">
                <p class="text-gray-600">Rotate, zoom, and inspect your 3D models in real-time</p>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing-section" class="py-20">
        <div class="container mx-auto px-6">
            <h2 class="text-4xl font-bold text-center mb-12 text-gray-800">Choose Your Plan</h2>
            <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                <!-- Free Plan -->
                <div class="bg-white p-8 rounded-lg shadow-lg">
                    <h3 class="text-2xl font-bold mb-4">Free</h3>
                    <div class="text-4xl font-bold mb-6">$0<span class="text-lg text-gray-600">/month</span></div>
                    <ul class="space-y-3 mb-8">
                        <li><i class="fas fa-check text-green-600 mr-2"></i> 5 projects maximum</li>
                        <li><i class="fas fa-check text-green-600 mr-2"></i> Basic 3D modeling tools</li>
                        <li><i class="fas fa-check text-green-600 mr-2"></i> STL export</li>
                        <li><i class="fas fa-check text-green-600 mr-2"></i> Community support</li>
                    </ul>
                    <button onclick="showSignup()" class="w-full px-6 py-3 bg-gray-200 text-gray-800 rounded-lg font-semibold hover:bg-gray-300 transition">
                        Get Started
                    </button>
                </div>
                <!-- Premium Plan -->
                <div class="bg-gradient-to-br from-purple-600 to-blue-600 text-white p-8 rounded-lg shadow-xl transform scale-105">
                    <div class="bg-white text-purple-700 inline-block px-3 py-1 rounded-full text-sm font-bold mb-4">POPULAR</div>
                    <h3 class="text-2xl font-bold mb-4">Premium</h3>
                    <div class="text-4xl font-bold mb-6">$29.99<span class="text-lg">/month</span></div>
                    <ul class="space-y-3 mb-8">
                        <li><i class="fas fa-check mr-2"></i> Unlimited projects</li>
                        <li><i class="fas fa-check mr-2"></i> Advanced 3D tools</li>
                        <li><i class="fas fa-check mr-2"></i> AI structural analysis</li>
                        <li><i class="fas fa-check mr-2"></i> AI design suggestions</li>
                        <li><i class="fas fa-check mr-2"></i> Enhanced visualization</li>
                        <li><i class="fas fa-check mr-2"></i> All export formats</li>
                        <li><i class="fas fa-check mr-2"></i> Priority support</li>
                        <li><i class="fas fa-check mr-2"></i> 100GB cloud storage</li>
                    </ul>
                    <button onclick="showSignup()" class="w-full px-6 py-3 bg-white text-purple-700 rounded-lg font-bold hover:bg-gray-100 transition">
                        Upgrade to Premium
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Dashboard Section (Hidden by default) -->
    <section id="dashboard-section" class="hidden py-20">
        <div class="container mx-auto px-6">
            <div class="flex justify-between items-center mb-8">
                <h2 class="text-4xl font-bold text-gray-800">My Dashboard</h2>
                <button onclick="createNewProject()" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                    <i class="fas fa-plus mr-2"></i> New Project
                </button>
            </div>
            
            <!-- Subscription Status -->
            <div id="subscription-status" class="bg-white p-6 rounded-lg shadow-lg mb-8">
                <h3 class="text-2xl font-bold mb-4">Subscription Status</h3>
                <div id="subscription-details"></div>
            </div>

            <!-- Projects Grid -->
            <div id="projects-grid" class="grid md:grid-cols-3 gap-6">
                <!-- Projects will be loaded here -->
            </div>
        </div>
    </section>

    <!-- Login Modal -->
    <div id="login-modal" class="modal">
        <div class="modal-content">
            <h2 class="text-2xl font-bold mb-6">Login</h2>
            <form onsubmit="handleLogin(event)">
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Email</label>
                    <input type="email" id="login-email" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Password</label>
                    <input type="password" id="login-password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                </div>
                <div class="flex gap-4">
                    <button type="submit" class="flex-1 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                        Login
                    </button>
                    <button type="button" onclick="closeModals()" class="flex-1 px-6 py-3 bg-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-400 transition">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Signup Modal -->
    <div id="signup-modal" class="modal">
        <div class="modal-content">
            <h2 class="text-2xl font-bold mb-6">Sign Up</h2>
            <form onsubmit="handleSignup(event)">
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Full Name</label>
                    <input type="text" id="signup-name" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Email</label>
                    <input type="email" id="signup-email" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Password</label>
                    <input type="password" id="signup-password" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" minlength="6" required>
                </div>
                <div class="flex gap-4">
                    <button type="submit" class="flex-1 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                        Sign Up
                    </button>
                    <button type="button" onclick="closeModals()" class="flex-1 px-6 py-3 bg-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-400 transition">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Project Editor Modal -->
    <div id="project-modal" class="modal">
        <div class="modal-content" style="max-width: 900px;">
            <h2 class="text-2xl font-bold mb-6">Create New Project</h2>
            <form onsubmit="handleCreateProject(event)">
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Project Title</label>
                    <input type="text" id="project-title" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 mb-2">Description</label>
                    <textarea id="project-description" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" rows="3"></textarea>
                </div>
                <div class="mb-6">
                    <label class="block text-gray-700 mb-2">Project Type</label>
                    <select id="project-type" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600" required>
                        <option value="bridge">Bridge</option>
                        <option value="road">Road</option>
                        <option value="building">Building</option>
                        <option value="infrastructure">Infrastructure</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div id="project-viewer" class="mb-6" style="height: 400px; background: #1a1a2e; border-radius: 8px;"></div>
                <div class="flex gap-4">
                    <button type="submit" class="flex-1 px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                        Create Project
                    </button>
                    <button type="button" onclick="closeModals()" class="flex-1 px-6 py-3 bg-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-400 transition">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
    <script src="/static/app.js"></script>
</body>
</html>
  `);
});

export default app;
