import { Context, Next } from 'hono';
import { sign, verify } from 'hono/jwt';
import type { Bindings, Variables } from '../types';

const JWT_SECRET = 'your-secret-key-change-in-production'; // TODO: Move to environment variable

export async function generateToken(payload: any): Promise<string> {
  return await sign(payload, JWT_SECRET);
}

export async function verifyToken(token: string): Promise<any> {
  try {
    return await verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

export async function authMiddleware(c: Context<{ Bindings: Bindings; Variables: Variables }>, next: Next) {
  const authHeader = c.req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ error: 'Unauthorized: No token provided' }, 401);
  }

  const token = authHeader.substring(7);
  const payload = await verifyToken(token);

  if (!payload) {
    return c.json({ error: 'Unauthorized: Invalid token' }, 401);
  }

  // Fetch user from database
  const user = await c.env.DB.prepare(
    'SELECT id, email, subscription_tier FROM users WHERE id = ?'
  ).bind(payload.userId).first();

  if (!user) {
    return c.json({ error: 'Unauthorized: User not found' }, 401);
  }

  c.set('user', {
    id: user.id as number,
    email: user.email as string,
    subscription_tier: user.subscription_tier as string
  });

  await next();
}

export async function premiumMiddleware(c: Context<{ Bindings: Bindings; Variables: Variables }>, next: Next) {
  const user = c.get('user');
  
  if (!user || user.subscription_tier !== 'premium') {
    return c.json({ error: 'Premium subscription required' }, 403);
  }

  await next();
}
