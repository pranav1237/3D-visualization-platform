import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const subscription = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// Get pricing information (public route, no auth required)
subscription.get('/pricing', async (c) => {
  return c.json({
    plans: {
      free: {
        price: 0,
        features: [
          '5 projects maximum',
          'Basic 3D modeling tools',
          'STL export only',
          'Community support'
        ]
      },
      premium: {
        monthly: {
          price: 29.99,
          currency: 'USD'
        },
        yearly: {
          price: 299.99,
          currency: 'USD',
          savings: '16%'
        },
        features: [
          'Unlimited projects',
          'Advanced 3D modeling tools',
          'AI-powered structural analysis',
          'AI design suggestions',
          'Enhanced visualization',
          'All export formats (STL, OBJ, GLTF, FBX)',
          'Priority support',
          'Cloud storage (100GB)',
          'Collaboration tools'
        ]
      }
    }
  });
});

// All other routes require authentication
subscription.use('/*', authMiddleware);

// Get current subscription status
subscription.get('/status', async (c) => {
  try {
    const user = c.get('user');

    const userDetails = await c.env.DB.prepare(
      'SELECT subscription_tier, stripe_customer_id, created_at FROM users WHERE id = ?'
    ).bind(user!.id).first();

    // Get usage stats
    const projectCount = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM projects WHERE user_id = ?'
    ).bind(user!.id).first();

    const aiUsageCount = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM usage_tracking WHERE user_id = ? AND action_type = ?'
    ).bind(user!.id, 'ai_visualization').first();

    const limits = user!.subscription_tier === 'premium' 
      ? { projects: 'Unlimited', ai_visualizations: 'Unlimited', export_formats: 'All' }
      : { projects: '5', ai_visualizations: '0', export_formats: 'Basic (STL)' };

    return c.json({
      subscription: {
        tier: userDetails?.subscription_tier,
        stripe_customer_id: userDetails?.stripe_customer_id,
        member_since: userDetails?.created_at
      },
      usage: {
        projects: projectCount?.count || 0,
        ai_visualizations: aiUsageCount?.count || 0
      },
      limits
    });
  } catch (error) {
    console.error('Get subscription error:', error);
    return c.json({ error: 'Failed to fetch subscription status' }, 500);
  }
});

// Create Stripe checkout session (simulation)
subscription.post('/create-checkout', async (c) => {
  try {
    const user = c.get('user');
    const { plan } = await c.req.json(); // 'monthly' or 'yearly'

    // In production, this would create actual Stripe checkout session
    // For now, we'll simulate it
    const prices = {
      monthly: 29.99,
      yearly: 299.99
    };

    const sessionId = `sim_${Date.now()}_${Math.random().toString(36).substring(7)}`;

    // Create pending subscription record
    await c.env.DB.prepare(
      'INSERT INTO subscription_history (user_id, subscription_tier, stripe_payment_intent_id, amount, status) VALUES (?, ?, ?, ?, ?)'
    ).bind(
      user!.id,
      'premium',
      sessionId,
      Math.round((prices[plan as keyof typeof prices] || prices.monthly) * 100),
      'pending'
    ).run();

    return c.json({
      message: 'Checkout session created',
      session_id: sessionId,
      // In production, return Stripe checkout URL
      checkout_url: `/payment/checkout?session=${sessionId}`,
      amount: prices[plan as keyof typeof prices] || prices.monthly
    });
  } catch (error) {
    console.error('Create checkout error:', error);
    return c.json({ error: 'Failed to create checkout session' }, 500);
  }
});

// Webhook to handle Stripe payment confirmation (simulation)
subscription.post('/webhook', async (c) => {
  try {
    // In production, verify Stripe webhook signature
    const { session_id, status } = await c.req.json();

    if (status === 'completed') {
      // Find the subscription record
      const record = await c.env.DB.prepare(
        'SELECT user_id FROM subscription_history WHERE stripe_payment_intent_id = ?'
      ).bind(session_id).first();

      if (record) {
        // Update user subscription
        await c.env.DB.prepare(
          'UPDATE users SET subscription_tier = ? WHERE id = ?'
        ).bind('premium', record.user_id).run();

        // Update subscription history
        await c.env.DB.prepare(
          'UPDATE subscription_history SET status = ? WHERE stripe_payment_intent_id = ?'
        ).bind('completed', session_id).run();

        return c.json({ message: 'Subscription activated' });
      }
    }

    return c.json({ message: 'Webhook processed' });
  } catch (error) {
    console.error('Webhook error:', error);
    return c.json({ error: 'Failed to process webhook' }, 500);
  }
});

// Cancel subscription
subscription.post('/cancel', async (c) => {
  try {
    const user = c.get('user');

    // In production, cancel Stripe subscription
    await c.env.DB.prepare(
      'UPDATE users SET subscription_tier = ? WHERE id = ?'
    ).bind('free', user!.id).run();

    return c.json({ message: 'Subscription cancelled successfully' });
  } catch (error) {
    console.error('Cancel subscription error:', error);
    return c.json({ error: 'Failed to cancel subscription' }, 500);
  }
});

export default subscription;
