import { Hono } from 'hono';
import bcrypt from 'bcryptjs';
import { generateToken } from '../middleware/auth';
import type { Bindings } from '../types';

const auth = new Hono<{ Bindings: Bindings }>();

// Signup endpoint
auth.post('/signup', async (c) => {
  try {
    const { email, password, full_name } = await c.req.json();

    // Validation
    if (!email || !password || !full_name) {
      return c.json({ error: 'All fields are required' }, 400);
    }

    if (password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters' }, 400);
    }

    // Check if user exists
    const existingUser = await c.env.DB.prepare(
      'SELECT id FROM users WHERE email = ?'
    ).bind(email).first();

    if (existingUser) {
      return c.json({ error: 'Email already registered' }, 409);
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 10);

    // Create user
    const result = await c.env.DB.prepare(
      'INSERT INTO users (email, password_hash, full_name, subscription_tier) VALUES (?, ?, ?, ?)'
    ).bind(email, passwordHash, full_name, 'free').run();

    const userId = result.meta.last_row_id;

    // Generate JWT token
    const token = await generateToken({ userId, email });

    return c.json({
      message: 'User created successfully',
      token,
      user: {
        id: userId,
        email,
        full_name,
        subscription_tier: 'free'
      }
    }, 201);
  } catch (error) {
    console.error('Signup error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

// Login endpoint
auth.post('/login', async (c) => {
  try {
    const { email, password } = await c.req.json();

    if (!email || !password) {
      return c.json({ error: 'Email and password are required' }, 400);
    }

    // Find user
    const user = await c.env.DB.prepare(
      'SELECT id, email, password_hash, full_name, subscription_tier FROM users WHERE email = ?'
    ).bind(email).first();

    if (!user) {
      return c.json({ error: 'Invalid credentials' }, 401);
    }

    // Verify password
    const isValid = await bcrypt.compare(password, user.password_hash as string);

    if (!isValid) {
      return c.json({ error: 'Invalid credentials' }, 401);
    }

    // Generate JWT token
    const token = await generateToken({ userId: user.id, email: user.email });

    return c.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        subscription_tier: user.subscription_tier
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    return c.json({ error: 'Internal server error' }, 500);
  }
});

export default auth;
