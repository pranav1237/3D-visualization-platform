import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const projects = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// All routes require authentication
projects.use('/*', authMiddleware);

// Get all projects for current user
projects.get('/', async (c) => {
  try {
    const user = c.get('user');
    
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC'
    ).bind(user!.id).all();

    return c.json({ projects: results });
  } catch (error) {
    console.error('Get projects error:', error);
    return c.json({ error: 'Failed to fetch projects' }, 500);
  }
});

// Get single project
projects.get('/:id', async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('id');

    const project = await c.env.DB.prepare(
      'SELECT * FROM projects WHERE id = ? AND user_id = ?'
    ).bind(projectId, user!.id).first();

    if (!project) {
      return c.json({ error: 'Project not found' }, 404);
    }

    return c.json({ project });
  } catch (error) {
    console.error('Get project error:', error);
    return c.json({ error: 'Failed to fetch project' }, 500);
  }
});

// Create new project
projects.post('/', async (c) => {
  try {
    const user = c.get('user');
    const { title, description, project_type, model_data } = await c.req.json();

    // Validation
    if (!title || !project_type) {
      return c.json({ error: 'Title and project type are required' }, 400);
    }

    // Check free tier limits (max 5 projects)
    if (user!.subscription_tier === 'free') {
      const count = await c.env.DB.prepare(
        'SELECT COUNT(*) as count FROM projects WHERE user_id = ?'
      ).bind(user!.id).first();

      if (count && (count.count as number) >= 5) {
        return c.json({ 
          error: 'Free tier limit reached (5 projects max). Upgrade to premium for unlimited projects.' 
        }, 403);
      }
    }

    // Create project
    const result = await c.env.DB.prepare(
      'INSERT INTO projects (user_id, title, description, project_type, model_data) VALUES (?, ?, ?, ?, ?)'
    ).bind(user!.id, title, description || null, project_type, model_data || null).run();

    // Track usage
    await c.env.DB.prepare(
      'INSERT INTO usage_tracking (user_id, action_type) VALUES (?, ?)'
    ).bind(user!.id, 'project_create').run();

    return c.json({
      message: 'Project created successfully',
      project_id: result.meta.last_row_id
    }, 201);
  } catch (error) {
    console.error('Create project error:', error);
    return c.json({ error: 'Failed to create project' }, 500);
  }
});

// Update project
projects.put('/:id', async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('id');
    const { title, description, project_type, model_data } = await c.req.json();

    // Check ownership
    const project = await c.env.DB.prepare(
      'SELECT id FROM projects WHERE id = ? AND user_id = ?'
    ).bind(projectId, user!.id).first();

    if (!project) {
      return c.json({ error: 'Project not found' }, 404);
    }

    // Update project
    await c.env.DB.prepare(
      'UPDATE projects SET title = ?, description = ?, project_type = ?, model_data = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(title, description || null, project_type, model_data || null, projectId).run();

    return c.json({ message: 'Project updated successfully' });
  } catch (error) {
    console.error('Update project error:', error);
    return c.json({ error: 'Failed to update project' }, 500);
  }
});

// Delete project
projects.delete('/:id', async (c) => {
  try {
    const user = c.get('user');
    const projectId = c.req.param('id');

    // Check ownership
    const project = await c.env.DB.prepare(
      'SELECT id FROM projects WHERE id = ? AND user_id = ?'
    ).bind(projectId, user!.id).first();

    if (!project) {
      return c.json({ error: 'Project not found' }, 404);
    }

    // Delete project
    await c.env.DB.prepare('DELETE FROM projects WHERE id = ?').bind(projectId).run();

    return c.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Delete project error:', error);
    return c.json({ error: 'Failed to delete project' }, 500);
  }
});

export default projects;
