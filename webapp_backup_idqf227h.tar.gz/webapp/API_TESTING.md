# API Testing Guide

This guide provides ready-to-use curl commands and examples for testing all API endpoints.

## Base URL

**Local Development**: `http://localhost:3000`  
**Production**: `https://your-project.pages.dev`

## Testing Workflow

### 1. Health Check

```bash
curl http://localhost:3000/api/health
```

**Expected Response**:
```json
{"status":"ok","timestamp":"2025-10-23T13:57:52.123Z"}
```

---

### 2. Get Pricing Information (Public)

```bash
curl http://localhost:3000/api/subscription/pricing
```

**Expected Response**:
```json
{
  "plans": {
    "free": {
      "price": 0,
      "features": ["5 projects maximum", "Basic 3D modeling tools", ...]
    },
    "premium": {
      "monthly": { "price": 29.99, "currency": "USD" },
      "yearly": { "price": 299.99, "currency": "USD", "savings": "16%" },
      "features": ["Unlimited projects", ...]
    }
  }
}
```

---

### 3. User Signup

```bash
curl -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@example.com",
    "password": "securePassword123",
    "full_name": "John Doe"
  }'
```

**Expected Response**:
```json
{
  "message": "User created successfully",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "john.doe@example.com",
    "full_name": "John Doe",
    "subscription_tier": "free"
  }
}
```

**Error Cases**:
- Email already exists: `{"error":"Email already registered"}` (409)
- Password too short: `{"error":"Password must be at least 6 characters"}` (400)
- Missing fields: `{"error":"All fields are required"}` (400)

---

### 4. User Login

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john.doe@example.com",
    "password": "securePassword123"
  }'
```

**Expected Response**:
```json
{
  "message": "Login successful",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": 1,
    "email": "john.doe@example.com",
    "full_name": "John Doe",
    "subscription_tier": "free"
  }
}
```

**Save the token for subsequent requests**:
```bash
export TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
```

---

### 5. Get Subscription Status

```bash
curl http://localhost:3000/api/subscription/status \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "subscription": {
    "tier": "free",
    "stripe_customer_id": null,
    "member_since": "2025-10-23 13:57:52"
  },
  "usage": {
    "projects": 0,
    "ai_visualizations": 0
  },
  "limits": {
    "projects": "5",
    "ai_visualizations": "0",
    "export_formats": "Basic (STL)"
  }
}
```

---

### 6. Create a Project

```bash
curl -X POST http://localhost:3000/api/projects \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Golden Gate Bridge",
    "description": "Suspension bridge design with cable-stayed towers",
    "project_type": "bridge",
    "model_data": "{\"version\":\"1.0\",\"objects\":[]}"
  }'
```

**Expected Response**:
```json
{
  "message": "Project created successfully",
  "project_id": 1
}
```

**Error Cases**:
- Free tier limit reached: `{"error":"Free tier limit reached (5 projects max). Upgrade to premium for unlimited projects."}` (403)
- Missing fields: `{"error":"Title and project type are required"}` (400)

---

### 7. Get All Projects

```bash
curl http://localhost:3000/api/projects \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "projects": [
    {
      "id": 1,
      "user_id": 1,
      "title": "Golden Gate Bridge",
      "description": "Suspension bridge design with cable-stayed towers",
      "project_type": "bridge",
      "model_data": "{\"version\":\"1.0\",\"objects\":[]}",
      "thumbnail_url": null,
      "is_public": 0,
      "created_at": "2025-10-23 13:57:52",
      "updated_at": "2025-10-23 13:57:52"
    }
  ]
}
```

---

### 8. Get Single Project

```bash
curl http://localhost:3000/api/projects/1 \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "project": {
    "id": 1,
    "user_id": 1,
    "title": "Golden Gate Bridge",
    "description": "Suspension bridge design with cable-stayed towers",
    "project_type": "bridge",
    "model_data": "{\"version\":\"1.0\",\"objects\":[]}",
    "thumbnail_url": null,
    "is_public": 0,
    "created_at": "2025-10-23 13:57:52",
    "updated_at": "2025-10-23 13:57:52"
  }
}
```

---

### 9. Update Project

```bash
curl -X PUT http://localhost:3000/api/projects/1 \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Golden Gate Bridge - Updated",
    "description": "Updated suspension bridge design",
    "project_type": "bridge",
    "model_data": "{\"version\":\"1.1\",\"objects\":[{\"type\":\"bridge\"}]}"
  }'
```

**Expected Response**:
```json
{
  "message": "Project updated successfully"
}
```

---

### 10. Delete Project

```bash
curl -X DELETE http://localhost:3000/api/projects/1 \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "message": "Project deleted successfully"
}
```

---

### 11. AI Structural Analysis (Premium Only)

```bash
curl -X POST http://localhost:3000/api/ai/analyze-structure \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": 1,
    "structure_data": {
      "material": "steel",
      "dimensions": {"length": 100, "width": 20, "height": 15}
    }
  }'
```

**Expected Response** (Premium users):
```json
{
  "message": "Structural analysis completed",
  "analysis_id": 1,
  "result": {
    "structural_integrity": 85.5,
    "load_capacity": 5500,
    "stress_points": [
      {"x": 0.5, "y": 0.3, "z": 0.1, "stress_level": 45.2}
    ],
    "recommendations": [
      "Consider reinforcing support columns",
      "Increase beam thickness at connection points"
    ],
    "safety_rating": "Excellent"
  }
}
```

**Error Response** (Free users):
```json
{
  "error": "Premium subscription required"
}
```

---

### 12. AI Design Suggestions (Premium Only)

```bash
curl -X POST http://localhost:3000/api/ai/design-suggestions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": 1,
    "requirements": {
      "budget": 5000000,
      "timeline": "12 months",
      "environmental_constraints": ["wind", "seismic"]
    }
  }'
```

**Expected Response** (Premium users):
```json
{
  "message": "Design suggestions generated",
  "suggestions": {
    "design_improvements": [
      "Optimize arch curvature for better load distribution",
      "Add expansion joints every 50 meters"
    ],
    "material_recommendations": [
      {"material": "High-strength steel", "benefit": "Increased durability"}
    ],
    "estimated_cost_savings": "15-20%",
    "construction_time": "Reduced by 3-4 months",
    "alternative_designs": [
      {"type": "Suspension bridge", "pros": ["Longer span", "Iconic appearance"]}
    ]
  }
}
```

---

### 13. AI Visualization Enhancement (Premium Only)

```bash
curl -X POST http://localhost:3000/api/ai/enhance-visualization \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "project_id": 1,
    "enhancement_type": "ultra_hd"
  }'
```

**Expected Response**:
```json
{
  "message": "Visualization enhanced successfully",
  "enhancement": {
    "type": "ultra_hd",
    "improvements": {
      "lighting": "Dynamic environmental lighting applied",
      "textures": "High-resolution PBR materials added",
      "atmosphere": "Realistic sky and weather effects",
      "details": "Additional structural details generated"
    },
    "render_quality": "Ultra HD",
    "processing_time": "2-3 minutes"
  }
}
```

---

### 14. Get AI Visualizations

```bash
curl http://localhost:3000/api/ai/visualizations/1 \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "visualizations": [
    {
      "id": 1,
      "project_id": 1,
      "user_id": 1,
      "visualization_type": "structural_analysis",
      "ai_model": "ai-structural-analyzer-v1",
      "input_prompt": "{\"material\":\"steel\",\"dimensions\":{...}}",
      "result_data": "{\"structural_integrity\":85.5,...}",
      "created_at": "2025-10-23 14:00:00"
    }
  ]
}
```

---

### 15. Create Checkout Session (Upgrade to Premium)

```bash
curl -X POST http://localhost:3000/api/subscription/create-checkout \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "plan": "monthly"
  }'
```

**Expected Response**:
```json
{
  "message": "Checkout session created",
  "session_id": "sim_1234567890_abc123",
  "checkout_url": "/payment/checkout?session=sim_1234567890_abc123",
  "amount": 29.99
}
```

---

### 16. Cancel Subscription

```bash
curl -X POST http://localhost:3000/api/subscription/cancel \
  -H "Authorization: Bearer $TOKEN"
```

**Expected Response**:
```json
{
  "message": "Subscription cancelled successfully"
}
```

---

## Complete Testing Script

Save this as `test_api.sh`:

```bash
#!/bin/bash

BASE_URL="http://localhost:3000"

echo "=== 3D Model Builder Pro - API Testing ==="

# 1. Health check
echo -e "\n1. Testing health endpoint..."
curl -s "$BASE_URL/api/health" | jq

# 2. Get pricing
echo -e "\n2. Getting pricing information..."
curl -s "$BASE_URL/api/subscription/pricing" | jq

# 3. Signup
echo -e "\n3. Creating new user..."
SIGNUP_RESPONSE=$(curl -s -X POST "$BASE_URL/api/auth/signup" \
  -H "Content-Type: application/json" \
  -d '{"email":"test'$(date +%s)'@example.com","password":"test123456","full_name":"Test User"}')
echo $SIGNUP_RESPONSE | jq

# 4. Extract token
TOKEN=$(echo $SIGNUP_RESPONSE | jq -r '.token')
echo -e "\nToken: ${TOKEN:0:50}..."

# 5. Get subscription status
echo -e "\n4. Getting subscription status..."
curl -s "$BASE_URL/api/subscription/status" \
  -H "Authorization: Bearer $TOKEN" | jq

# 6. Create project
echo -e "\n5. Creating a bridge project..."
curl -s -X POST "$BASE_URL/api/projects" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Bridge","description":"Test project","project_type":"bridge"}' | jq

# 7. Get projects
echo -e "\n6. Getting all projects..."
curl -s "$BASE_URL/api/projects" \
  -H "Authorization: Bearer $TOKEN" | jq

echo -e "\n=== Testing Complete ==="
```

Make it executable and run:
```bash
chmod +x test_api.sh
./test_api.sh
```

---

## Error Codes Reference

| Status Code | Meaning | Common Causes |
|------------|---------|---------------|
| 200 | OK | Successful GET request |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid input, missing fields |
| 401 | Unauthorized | Invalid or missing token |
| 403 | Forbidden | Premium feature, tier limit reached |
| 404 | Not Found | Resource doesn't exist |
| 409 | Conflict | Duplicate email, resource exists |
| 500 | Server Error | Database or internal error |

---

## Authentication Headers

All protected endpoints require:
```
Authorization: Bearer <your-jwt-token>
```

Get your token from signup or login response and include it in all subsequent requests.

---

**Last Updated**: 2025-10-23
