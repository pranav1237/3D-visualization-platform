# 3D Model Builder Pro

A professional web-based 3D visualization platform for infrastructure design and modeling, featuring AI-powered structural analysis, real-time 3D rendering, and subscription-based premium features.

## 🌐 URLs

- **Development Server**: https://3000-idqf227hdh5u0neaj4rjn-2e77fc33.sandbox.novita.ai
- **Project Backup**: https://page.gensparksite.com/project_backups/3d-model-builder-pro-v1.0.0.tar.gz
- **Production**: (To be deployed on Cloudflare Pages)

## 🎯 Project Overview

**3D Model Builder Pro** is a cutting-edge web application that enables engineers, architects, and designers to create and visualize 3D models for real-world infrastructure projects including:

- 🌉 **Bridges** - Cable-stayed, suspension, arch, and beam bridges
- 🛣️ **Roads & Highways** - Complex road networks with interchanges
- 🏗️ **Buildings** - Commercial, residential, and industrial structures
- 🏭 **Infrastructure** - Tunnels, dams, and other civil engineering projects

## ✨ Key Features

### Free Tier Features
- ✅ Create up to 5 projects
- ✅ Interactive 3D modeling tools with Three.js
- ✅ Real-time 3D visualization with orbit controls
- ✅ Basic export formats (STL)
- ✅ Project management dashboard
- ✅ Cloud storage for projects
- ✅ Community support

### Premium Tier Features ($29.99/month)
- 🚀 **Unlimited Projects** - No project limits
- 🧠 **AI Structural Analysis** - Automated stress analysis, load capacity calculations, and safety ratings
- 💡 **AI Design Suggestions** - Intelligent recommendations for optimization and cost savings
- 🎨 **Enhanced Visualization** - Ultra HD rendering with realistic materials and lighting
- 📦 **Advanced Export** - STL, OBJ, GLTF, FBX formats
- ☁️ **100GB Cloud Storage** - Extended storage for large projects
- 🤝 **Collaboration Tools** - Share and collaborate with team members
- ⚡ **Priority Support** - Fast-track support responses

## 🏗️ Technology Stack

### Backend
- **Hono** - Lightweight, fast web framework for Cloudflare Workers
- **Cloudflare D1** - Serverless SQLite database for data storage
- **JWT Authentication** - Secure token-based authentication
- **bcryptjs** - Password hashing and security

### Frontend
- **Three.js** - 3D rendering and visualization
- **Tailwind CSS** - Modern utility-first CSS framework
- **Axios** - HTTP client for API communication
- **Vanilla JavaScript** - No heavy frameworks, optimized performance

### Deployment
- **Cloudflare Pages** - Edge deployment with global CDN
- **Wrangler** - CLI tool for Cloudflare development
- **PM2** - Process manager for local development

## 📊 Data Architecture

### Database Schema

#### Users Table
```sql
- id (Primary Key)
- email (Unique)
- password_hash
- full_name
- subscription_tier (free/premium)
- stripe_customer_id
- created_at, updated_at
```

#### Projects Table
```sql
- id (Primary Key)
- user_id (Foreign Key)
- title
- description
- project_type (bridge/road/building/infrastructure/other)
- model_data (JSON - stores 3D model vertices, materials, etc.)
- thumbnail_url
- is_public
- created_at, updated_at
```

#### AI Visualizations Table
```sql
- id (Primary Key)
- project_id (Foreign Key)
- user_id (Foreign Key)
- visualization_type
- ai_model
- input_prompt
- result_data (JSON - stores AI analysis results)
- created_at
```

#### Subscription History Table
```sql
- id (Primary Key)
- user_id (Foreign Key)
- subscription_tier
- stripe_subscription_id
- stripe_payment_intent_id
- amount
- currency
- status (pending/completed/failed/cancelled)
- created_at
```

#### Usage Tracking Table
```sql
- id (Primary Key)
- user_id (Foreign Key)
- action_type (project_create/ai_visualization/model_export)
- created_at
```

## 🔒 Authentication & Security

- **JWT Tokens** - Secure, stateless authentication
- **bcrypt Password Hashing** - Industry-standard password protection
- **CORS Protection** - Cross-Origin Resource Sharing configured
- **Input Validation** - Server-side validation for all inputs
- **Rate Limiting** - (To be implemented) Prevent abuse

## 💳 Payment Integration

The platform integrates with **Stripe** for secure payment processing:

- **PCI Compliance** - All payments handled by Stripe
- **Multiple Payment Methods** - Credit cards, debit cards, digital wallets
- **Subscription Management** - Automatic billing and cancellation
- **Webhook Integration** - Real-time payment status updates
- **Secure Tokens** - No sensitive payment data stored

### Payment Flow
1. User selects premium plan
2. System creates Stripe checkout session
3. User completes payment on Stripe-hosted page
4. Stripe webhook confirms payment
5. User subscription upgraded automatically
6. Access to premium features enabled immediately

## 🎮 User Guide

### Getting Started
1. **Sign Up** - Create a free account with email and password
2. **Login** - Access your dashboard
3. **Create Project** - Click "New Project" to start modeling
4. **Build in 3D** - Use the interactive viewer to create your model
5. **Save & Export** - Save your work and export in various formats

### Creating a 3D Model
1. Select project type (bridge, road, building, etc.)
2. Use the 3D viewer controls:
   - **Left Click + Drag** - Rotate view
   - **Right Click + Drag** - Pan view
   - **Scroll Wheel** - Zoom in/out
3. Add structural elements using the toolbar
4. Adjust materials, colors, and properties
5. Save project to cloud

### Using AI Features (Premium)
1. Open an existing project
2. Click "AI Analysis" button
3. Choose analysis type:
   - Structural Integrity Analysis
   - Design Suggestions
   - Visualization Enhancement
4. Review AI-generated recommendations
5. Apply suggestions to your model

## 🚀 API Endpoints

### Authentication
- `POST /api/auth/signup` - Create new account
- `POST /api/auth/login` - Login and get JWT token

### Projects
- `GET /api/projects` - Get all user projects
- `GET /api/projects/:id` - Get single project
- `POST /api/projects` - Create new project
- `PUT /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project

### AI Features (Premium Only)
- `POST /api/ai/analyze-structure` - Structural analysis
- `POST /api/ai/design-suggestions` - Get AI design suggestions
- `POST /api/ai/enhance-visualization` - Enhance rendering
- `GET /api/ai/visualizations/:project_id` - Get AI visualizations

### Subscription
- `GET /api/subscription/status` - Get subscription status and usage
- `GET /api/subscription/pricing` - Get pricing information
- `POST /api/subscription/create-checkout` - Create payment session
- `POST /api/subscription/webhook` - Stripe webhook handler
- `POST /api/subscription/cancel` - Cancel subscription

## 🛠️ Development

### Prerequisites
- Node.js 18+
- npm or yarn
- Wrangler CLI

### Local Setup
```bash
# Clone repository
git clone <repository-url>
cd webapp

# Install dependencies
npm install

# Initialize database
npm run db:migrate:local
npm run db:seed

# Build project
npm run build

# Start development server
npm run dev:sandbox
# or with PM2
pm2 start ecosystem.config.cjs
```

### Database Management
```bash
# Apply migrations (local)
npm run db:migrate:local

# Apply migrations (production)
npm run db:migrate:prod

# Seed database
npm run db:seed

# Reset database
npm run db:reset

# Database console (local)
npm run db:console:local

# Database console (production)
npm run db:console:prod
```

### Testing
```bash
# Test API health
curl http://localhost:3000/api/health

# Test signup
curl -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","full_name":"Test User"}'

# Test login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123"}'
```

## 📦 Deployment

### Cloudflare Pages Deployment

**Note**: Before deployment, ensure you have:
- Cloudflare account
- Cloudflare API token configured
- Production D1 database created

```bash
# 1. Create production D1 database
npx wrangler d1 create webapp-production

# 2. Update wrangler.jsonc with database_id

# 3. Apply migrations to production
npm run db:migrate:prod

# 4. Build project
npm run build

# 5. Deploy to Cloudflare Pages
npm run deploy:prod
```

## 📈 Future Enhancements

### Planned Features
- [ ] **Collaborative Editing** - Real-time multi-user collaboration
- [ ] **Advanced Materials Library** - PBR materials, textures, and shaders
- [ ] **Physics Simulation** - Real-time structural simulation
- [ ] **VR/AR Support** - Virtual reality visualization
- [ ] **Mobile App** - iOS and Android native apps
- [ ] **API Access** - RESTful API for third-party integrations
- [ ] **Plugins System** - Extensible plugin architecture
- [ ] **Templates Library** - Pre-built project templates
- [ ] **Team Workspaces** - Organization and team management
- [ ] **Advanced Analytics** - Usage analytics and insights

### AI Enhancements
- [ ] **Automated Design Generation** - Generate complete designs from requirements
- [ ] **Material Optimization** - AI-suggested material selection
- [ ] **Cost Estimation** - Automatic project cost calculations
- [ ] **Code Compliance** - Check designs against building codes
- [ ] **Environmental Analysis** - Carbon footprint and sustainability metrics

## 🐛 Known Issues

- AI features currently use simulated responses (production will integrate OpenAI/Anthropic APIs)
- Payment integration uses simulated Stripe workflow (production will use real Stripe API)
- Export functionality is basic (will be enhanced with worker-based processing)

## 📄 License

MIT License - see LICENSE file for details

## 👥 Support

- **Community Forum**: (To be created)
- **Email Support**: support@3dmodelbuilder.pro
- **Premium Support**: priority@3dmodelbuilder.pro

## 🎯 Current Status

✅ **Completed Features**:
- User authentication system
- Project management (CRUD operations)
- 3D visualization with Three.js
- Database schema and migrations
- Free/Premium tier management
- AI feature framework (simulation)
- Payment integration framework (simulation)
- Responsive UI with Tailwind CSS
- Dashboard with usage tracking

🚧 **In Progress**:
- GitHub repository setup
- Cloudflare Pages production deployment
- Real Stripe API integration
- Real AI API integration (OpenAI/Anthropic)

📅 **Last Updated**: 2025-10-23

---

**Built with ❤️ using Hono, Three.js, and Cloudflare Pages**
