# Deployment Guide

## Production Deployment to Cloudflare Pages

### Prerequisites

1. **Cloudflare Account**
   - Sign up at https://dash.cloudflare.com/sign-up
   - Note your Account ID from the dashboard

2. **Install Wrangler CLI** (already installed in this project)
   ```bash
   npm install -g wrangler
   ```

3. **Authenticate with Cloudflare**
   ```bash
   wrangler login
   ```

### Step 1: Create Production D1 Database

```bash
# Create the production database
npx wrangler d1 create webapp-production

# Output will show:
# ✅ Successfully created DB 'webapp-production' in region WEUR
# 
# [[d1_databases]]
# binding = "DB"
# database_name = "webapp-production"
# database_id = "xxxxx-xxxx-xxxx-xxxx-xxxxxxxxx"
```

**IMPORTANT**: Copy the `database_id` from the output.

### Step 2: Update Configuration

Edit `wrangler.jsonc` and replace the `database_id`:

```jsonc
{
  "d1_databases": [
    {
      "binding": "DB",
      "database_name": "webapp-production",
      "database_id": "YOUR-ACTUAL-DATABASE-ID-HERE"  // Replace this
    }
  ]
}
```

### Step 3: Apply Migrations to Production

```bash
# Apply database schema to production
npm run db:migrate:prod

# This will create all tables and indexes in production
```

### Step 4: Build the Project

```bash
# Build for production
npm run build

# This creates the dist/ folder with:
# - _worker.js (compiled Hono app)
# - _routes.json (routing configuration)
# - public/ static assets
```

### Step 5: Create Cloudflare Pages Project

```bash
# Create the Pages project
npx wrangler pages project create webapp \
  --production-branch main \
  --compatibility-date 2025-10-23
```

### Step 6: Deploy to Cloudflare Pages

```bash
# Deploy the built application
npm run deploy:prod
# or
npx wrangler pages deploy dist --project-name webapp

# You'll receive deployment URLs:
# ✨ Deployment complete! Take a peek over at
#   https://xxxxxxxx.webapp.pages.dev
```

### Step 7: Configure Environment Variables

If you plan to use real AI APIs or Stripe:

```bash
# Set JWT secret
npx wrangler pages secret put JWT_SECRET --project-name webapp
# Enter: your-production-secret-key

# Set Stripe API key (when integrating real Stripe)
npx wrangler pages secret put STRIPE_SECRET_KEY --project-name webapp
# Enter: sk_live_xxxxx

# Set OpenAI API key (when integrating real AI)
npx wrangler pages secret put OPENAI_API_KEY --project-name webapp
# Enter: sk-xxxxx
```

### Step 8: Custom Domain (Optional)

```bash
# Add custom domain
npx wrangler pages domain add yourdomain.com --project-name webapp

# Follow the instructions to update DNS records
```

## Verification

After deployment, test your production API:

```bash
# Test health endpoint
curl https://your-project.pages.dev/api/health

# Test pricing endpoint
curl https://your-project.pages.dev/api/subscription/pricing

# Test signup
curl -X POST https://your-project.pages.dev/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","full_name":"Test User"}'
```

## Local Development vs Production

### Local Development
- Uses `.wrangler/state/v3/d1/` for local SQLite database
- Run with: `npm run dev:sandbox` or `pm2 start ecosystem.config.cjs`
- Access at: `http://localhost:3000`

### Production
- Uses Cloudflare D1 distributed database
- Deployed via: `npm run deploy:prod`
- Access at: `https://your-project.pages.dev`

## Continuous Deployment

### Option 1: GitHub Actions (Recommended)

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Cloudflare Pages

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    name: Deploy
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm install
      - run: npm run build
      - name: Deploy to Cloudflare Pages
        uses: cloudflare/pages-action@v1
        with:
          apiToken: ${{ secrets.CLOUDFLARE_API_TOKEN }}
          accountId: ${{ secrets.CLOUDFLARE_ACCOUNT_ID }}
          projectName: webapp
          directory: dist
          gitHubToken: ${{ secrets.GITHUB_TOKEN }}
```

### Option 2: Manual Deploy

```bash
# Pull latest code
git pull origin main

# Build and deploy
npm run deploy:prod
```

## Monitoring and Logs

### View Production Logs
```bash
# Tail production logs
npx wrangler pages deployment tail --project-name webapp
```

### View Analytics
Visit: https://dash.cloudflare.com/pages/projects/webapp

## Database Management

### Backup Production Database
```bash
# Export production data
npx wrangler d1 export webapp-production --output=backup.sql --remote
```

### Query Production Database
```bash
# Interactive SQL console
npx wrangler d1 execute webapp-production --remote

# Execute SQL file
npx wrangler d1 execute webapp-production --file=query.sql --remote
```

## Rollback

If something goes wrong:

```bash
# List deployments
npx wrangler pages deployment list --project-name webapp

# Rollback to previous deployment
npx wrangler pages deployment tail --project-name webapp --deployment-id <DEPLOYMENT_ID>
```

## Troubleshooting

### Issue: Database not found
**Solution**: Ensure you've created the production database and updated the `database_id` in `wrangler.jsonc`

### Issue: Authentication errors
**Solution**: Check that JWT_SECRET is set in production secrets

### Issue: 404 errors on routes
**Solution**: Ensure `npm run build` completed successfully and `dist/_routes.json` exists

### Issue: CORS errors
**Solution**: Check that CORS middleware is enabled for `/api/*` routes in `src/index.tsx`

## Performance Optimization

### Enable Caching
Add to `wrangler.jsonc`:
```jsonc
{
  "routes": [
    {
      "pattern": "/static/*",
      "cache": true
    }
  ]
}
```

### Enable Compression
Cloudflare automatically compresses responses. No configuration needed.

## Security Checklist

- ✅ JWT secret configured in production
- ✅ HTTPS enforced (automatic with Cloudflare Pages)
- ✅ CORS properly configured
- ✅ Input validation on all API endpoints
- ✅ Password hashing with bcrypt
- ✅ Rate limiting (to be implemented)
- ✅ SQL injection prevention (parameterized queries)

## Cost Estimation

### Cloudflare Pages Free Tier
- 500 builds per month
- Unlimited requests
- Unlimited bandwidth
- 100,000 D1 reads per day
- 50,000 D1 writes per day

### Cloudflare Pages Pro ($20/month)
- Unlimited builds
- Advanced analytics
- Increased D1 limits

For most applications, the free tier is sufficient for development and moderate production use.

## Support

For deployment issues:
- Cloudflare Community: https://community.cloudflare.com/
- Cloudflare Discord: https://discord.cloudflare.com/
- Documentation: https://developers.cloudflare.com/pages/

---

Last updated: 2025-10-23
