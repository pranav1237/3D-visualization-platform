# Quick Start Guide

Get your 3D Model Builder Pro up and running in 5 minutes!

## 🚀 Prerequisites

- Node.js 18+ installed
- npm or yarn package manager
- Basic terminal/command line knowledge

## 📦 Installation

### 1. Clone or Extract Project

If you have the backup file:
```bash
# Extract the backup
tar -xzf 3d-model-builder-pro-v1.0.0.tar.gz
cd webapp
```

Or clone from repository:
```bash
git clone <your-repo-url>
cd webapp
```

### 2. Install Dependencies

```bash
npm install
```

This will install all required packages including Hono, Wrangler, Three.js, etc.

### 3. Initialize Database

```bash
# Create local database and apply schema
npm run db:migrate:local

# Seed with sample data (optional)
npm run db:seed
```

### 4. Build the Project

```bash
npm run build
```

This creates the `dist/` folder with your compiled application.

### 5. Start Development Server

**Option A: Using npm script**
```bash
npm run dev:sandbox
```

**Option B: Using PM2 (recommended)**
```bash
# Start with PM2
pm2 start ecosystem.config.cjs

# Check status
pm2 status

# View logs
pm2 logs webapp --nostream
```

### 6. Access the Application

Open your browser and navigate to:
```
http://localhost:3000
```

🎉 **You're ready to go!**

---

## 🎯 First Steps

### Create Your First Account

1. Click "Sign Up" in the navigation
2. Enter your details:
   - **Name**: John Doe
   - **Email**: john@example.com
   - **Password**: securepass123
3. Click "Sign Up"
4. You'll be automatically logged in!

### Create Your First Project

1. Click "Dashboard" from the user menu
2. Click "New Project" button
3. Fill in project details:
   - **Title**: My First Bridge
   - **Description**: A suspension bridge design
   - **Type**: Bridge
4. Click "Create Project"
5. Your project is saved!

### Explore the 3D Viewer

1. Scroll down to "Interactive 3D Viewer" section
2. Use your mouse to interact:
   - **Left Click + Drag**: Rotate the view
   - **Right Click + Drag**: Pan the view
   - **Scroll Wheel**: Zoom in/out
3. See the demo bridge structure render in real-time!

---

## 🧪 Testing the API

### Quick API Test

```bash
# Test health endpoint
curl http://localhost:3000/api/health

# Expected: {"status":"ok","timestamp":"..."}
```

### Complete Test Flow

```bash
# Create a user
curl -X POST http://localhost:3000/api/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"test123","full_name":"Test User"}'

# Response includes a token - save it!
# TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."

# Create a project (replace TOKEN with your actual token)
curl -X POST http://localhost:3000/api/projects \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"title":"Test Bridge","project_type":"bridge"}'
```

For more detailed testing, see [API_TESTING.md](./API_TESTING.md)

---

## 📁 Project Structure Quick Reference

```
webapp/
├── src/
│   ├── index.tsx           # Main app & routes
│   ├── routes/             # API route handlers
│   │   ├── auth.ts        # Authentication
│   │   ├── projects.ts    # Project management
│   │   ├── ai.ts          # AI features
│   │   └── subscription.ts # Payments
│   ├── middleware/         # Auth middleware
│   └── types.ts           # TypeScript types
├── public/static/
│   ├── app.js             # Frontend JavaScript
│   └── style.css          # Custom styles
├── migrations/            # Database migrations
├── package.json           # Dependencies & scripts
└── wrangler.jsonc        # Cloudflare config
```

---

## 🛠️ Common Commands

### Development
```bash
# Start dev server
npm run dev:sandbox

# Start with PM2
pm2 start ecosystem.config.cjs

# Restart PM2 service
pm2 restart webapp

# Stop PM2 service
pm2 stop webapp

# View PM2 logs
pm2 logs webapp --nostream
```

### Database
```bash
# Apply migrations (local)
npm run db:migrate:local

# Seed database
npm run db:seed

# Reset database
npm run db:reset
```

### Building
```bash
# Build for production
npm run build

# Preview build
npm run preview
```

### Cleanup
```bash
# Clean port 3000
npm run clean-port

# Or manually
fuser -k 3000/tcp
```

---

## 🔧 Troubleshooting

### Port 3000 Already in Use
```bash
# Kill process on port 3000
npm run clean-port

# Or use pm2
pm2 delete all
```

### Database Errors
```bash
# Reset database completely
npm run db:reset
```

### Build Errors
```bash
# Clean and rebuild
rm -rf dist .wrangler
npm run build
```

### PM2 Not Found
```bash
# PM2 is pre-installed in sandbox
# If not available, install globally:
npm install -g pm2
```

---

## 📚 Learn More

### Essential Documentation
- **README.md** - Full project documentation
- **FEATURES.md** - Complete feature list
- **API_TESTING.md** - API endpoint testing guide
- **DEPLOYMENT.md** - Production deployment guide

### Key Features to Try

**Free Tier:**
- Create up to 5 projects
- Interactive 3D modeling
- Basic export (STL)
- Project dashboard

**Premium Tier:**
- Unlimited projects
- AI structural analysis
- AI design suggestions
- Enhanced visualization
- All export formats

---

## 🚀 Next Steps

### 1. Explore the UI
- Sign up for an account
- Create multiple projects
- Try different project types (bridge, road, building)
- Explore the dashboard

### 2. Test the API
- Use the curl commands above
- Try creating, updating, and deleting projects
- Check subscription status
- Test pricing endpoint

### 3. Customize
- Modify the 3D viewer in `public/static/app.js`
- Add new project types in `src/routes/projects.ts`
- Customize the UI in `src/index.tsx`
- Add new API endpoints

### 4. Deploy to Production
- Follow [DEPLOYMENT.md](./DEPLOYMENT.md)
- Set up Cloudflare account
- Create production D1 database
- Deploy to Cloudflare Pages

---

## 💡 Tips & Tricks

### Development Workflow
1. Make changes to source files
2. Run `npm run build`
3. Restart PM2: `pm2 restart webapp`
4. Test changes at `http://localhost:3000`

### Database Management
- Always backup before migrations
- Use `--local` flag for development
- Use `--remote` flag for production
- Keep migration files in git

### Performance
- Three.js viewer runs client-side
- API responses are cached
- D1 database has automatic indexes
- Cloudflare Pages provides global CDN

---

## 🆘 Getting Help

### Resources
- Check existing documentation files
- Review code comments
- Test API endpoints
- Check PM2 logs: `pm2 logs webapp`

### Common Issues
- **Token expired**: Re-login to get new token
- **Free tier limit**: Upgrade to premium or delete projects
- **Database locked**: Stop all PM2 processes and restart
- **Build fails**: Clear dist and .wrangler folders

---

## ✅ Verification Checklist

After setup, verify everything works:

- [ ] Server starts on port 3000
- [ ] Home page loads in browser
- [ ] API health check returns OK
- [ ] Can create new account
- [ ] Can login successfully
- [ ] Dashboard loads correctly
- [ ] Can create new project
- [ ] 3D viewer displays correctly
- [ ] PM2 logs show no errors

If all checks pass, you're ready to develop! 🎉

---

**Time to Complete**: ~5 minutes  
**Difficulty**: Beginner-friendly  
**Support**: See documentation files for detailed help

---

Happy building! 🚀🏗️
