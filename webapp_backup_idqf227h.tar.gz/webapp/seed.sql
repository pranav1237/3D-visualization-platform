-- Sample users for testing (password: demo123)
-- Password hash generated using bcrypt for 'demo123'
INSERT OR IGNORE INTO users (id, email, password_hash, full_name, subscription_tier) VALUES 
  (1, 'demo@example.com', '$2a$10$rZGKqH8R8XvvXxC.vBKqL.xJ5vXJFq3wU5Z8ZN1Q5K8Z8Z8Z8Z8Z8', 'Demo User', 'free'),
  (2, 'premium@example.com', '$2a$10$rZGKqH8R8XvvXxC.vBKqL.xJ5vXJFq3wU5Z8ZN1Q5K8Z8Z8Z8Z8Z8', 'Premium User', 'premium');

-- Sample projects
INSERT OR IGNORE INTO projects (user_id, title, description, project_type, is_public) VALUES 
  (1, 'Golden Gate Bridge Replica', 'A detailed 3D model of the Golden Gate Bridge', 'bridge', 1),
  (1, 'Highway Infrastructure', 'Multi-lane highway with interchanges', 'road', 1),
  (2, 'Modern Skyscraper', 'Contemporary office building design', 'building', 0);
